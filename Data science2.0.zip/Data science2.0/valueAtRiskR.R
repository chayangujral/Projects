# register function Rate of Return
fpctcng<-function(x,n){
  # returns the percentage difference between the current value and the previous value of a vector
  numVec<-x[(n+1):length(x)]
  denomVec<-x[1:(length(x)-n)]
  # numVec/denomVec-1
  c(rep(NA,n),numVec/denomVec-1)}


#############################################
############# n company Value at Risk

# import data
library(readxl)
df <- read_excel("J:/df")
View(df)

#############################################
# do value at risk

names(bbts500cos2)
dim(bbts500cos2)
df<- bbts500cos2[ , c("amzn","trip","msft","nflx","aapl")]
names(df)
vdf<-df
vdf<-as.data.frame(df)

pordf<-vdf
nSecs<-length(names(pordf))
nSecs
#don't do "for" loops  - for (i in 1:6){  }
# use vectorized loops (implicit looping)

sapply(pordf,fpctcng,1)
rrdf<- data.frame(sapply(pordf,fpctcng,1))
rrdf
rrdf1<-data.frame(sapply(1:nSecs,function(i){fpctcng(pordf[,i],1)}))
rrdf1

portWgtsVec<-rep(1/nSecs,nSecs)  #equal weights, or
#portWgtsVec<-c(.1,.15,.05,.2,.3,.2)  #unequal, specified weights
sum(portWgtsVec)

# 10 million portfolio
dollarReturnDF<-rrdf[,1:nSecs]*portWgtsVec*10 # in millions
dollarReturnVector<-apply(dollarReturnDF,1,sum,na.rm=T)  # in millions

#5% and 1% parametric VAR
pvar5<-mean(dollarReturnVector,na.rm=T)-1.65*sd(dollarReturnVector,na.rm=T)
pvar1<-mean(dollarReturnVector,na.rm=T)-2.33*sd(dollarReturnVector,na.rm=T)

#5% and 1% historical VAR
n<-length(dollarReturnVector)
hvar5<-sort(dollarReturnVector)[round(n*.05,0)]
hvar1<-sort(dollarReturnVector)[round(n*.01,0)]

varResultsdf<-data.frame(matrix(1,2))
varResultsdf[1,1]<-pvar1
varResultsdf[2,1]<-pvar5
varResultsdf[1,2]<-hvar1
varResultsdf[2,2]<-hvar5
names(varResultsdf)<- c("1%","5%")
row.names(varResultsdf)<-c("parametric","historical")
varResultsdf


describe(data.frame(dollarReturnVector))   # need libray "psyche"
par(mfcol=c(2,2))
hist(dollarReturnVector)
ts.plot(dollarReturnVector); abline(h=0)



#############################################
############# n company Value at Risk

# import data
library(readxl)
df <- read_excel("J:/df")
View(df)

#############################################

secVec<- c("msft","fdx","dis","wmt")
pordf<- df[,is.element(df$tkr,secVec)]
nSecs<-dim(pordf)[2]
portRedf<-as.data.frame(rep(999,dim(pordf)[1]))
for (i in 1:nSecs){portRedf<-data.frame(portRedf,fpctcng(pordf[,i],1))}
portRedf
portRedf<-portRedf[,-1]

portWgtsVec<-rep(1/nSecs,nSecs)  #equal weights, or
#  portWgtsVec<-c(.1,.15,.05,.2,.3,.2)  #unequal, specified weights
sum(portWgtsVec)

dollarReturnDF<-portRedf[,1:nSecs]*portWgtsVec*10000000
dollarReturnVector<-apply(dollarReturnDF,1,sum,na.rm=T)

#5% and 1% parametric VAR
pvar5<-mean(dollarReturnVector,na.rm=T)-1.65*stdev(dollarReturnVector,na.rm=T)
pvar1<-mean(dollarReturnVector,na.rm=T)-2.33*stdev(dollarReturnVector,na.rm=T)

#5% and 1% historical VAR
n<-length(dollarReturnVector)
hvar5<-sort(dollarReturnVector)[round(n*.05,0)]
hvar1<-sort(dollarReturnVector)[round(n*.01,0)]

vardf<-data.frame(matrix(2,2))
vardf[1,1]<-pvar1
vardf[1,2]<-pvar5
vardf[2,1]<-hvar1
vardf[2,2]<-hvar5
names(vardf)<-c("1%","5%")
row.names(vardf)<-c("parametric","historical")
vardf

fdesstat(data.frame(dollarReturnVector))
par(mfcol=c(2,2))
	hist(dollarReturnVector)
	tsplot(dollarReturnVector); abline(h=0)


