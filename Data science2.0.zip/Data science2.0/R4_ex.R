###Loading relevent Packages

library(readxl)
library(ggplot2)
library(dplyr)

###Importing Data
my_data <- read_excel("~/DS New Hire Exercise 8-8-18.xlsx", 
    sheet = "Data")
View(my_data)
head(my_data)#Reading Data
dim(my_data)#Dimensions for data

my_data<- as.data.frame(na.omit(my_data[1:4]))#removed NAs and converted to data frame
dim(my_data)# dimensions after cleaning

# Calculating unique user ID

u_id = my_data %>% select(ID) %>% count(ID)
dim(u_id)[1]#Total No. of unique users in data 

## Calculating user with most views
u_user<-as.data.frame(my_data 
                       %>% select(ID) 
                       %>% group_by(ID) 
                       %>% summarise(appear.count=n()) 
                       %>% arrange(desc(appear.count)))
u_user
sum(u_user$appear.count)
u_user %>% select(ID, appear.count) %>% filter(appear.count == max(appear.count))


## calculating users with least amount of visits

users_one_views<- as.data.frame(u_user %>% select(ID, appear.count) %>% filter(appear.count  ==1))
count(u_user %>% select(ID, appear.count) %>% filter(appear.count  ==1))

#Calculating Total no. of Genres and total Views per Genre
u_genre<-as.data.frame(my_data 
                       %>% select(Genre) 
                       %>% group_by(Genre) 
                       %>% summarise(appear.count=n()) 
                       %>% arrange(desc(appear.count))) 
u_genre

dim(u_genre)[1]


##Calculating Genres with Distinct hits by users

u_genre1<-as.data.frame(unique(my_data[,c(1,4)]) 
                       %>% select(Genre) 
                       %>% group_by(Genre) 
                       %>% summarise(appear.count=n()) 
                       %>% arrange(desc(appear.count))) 
u_genre1





### Calculating counts for distinct user creation each day
u_date<-as.data.frame(unique(my_data[,1:2]) 
                      %>% select(Account_Active_Date) 
                      %>% group_by(Account_Active_Date) 
                      %>% summarise(appear.count=n()) 
                      %>% arrange(desc(appear.count)))

dim(u_date)[1]


#### Calculating Total views per usage data and date with max usage with all users
use_date1<-as.data.frame(my_data 
                         %>% select(Use_Date) 
                         %>% group_by(Use_Date) 
                         %>% summarise(appear.count=n()) 
                         %>% arrange(desc(appear.count)))

use_date1 %>% select(Use_Date,appear.count) %>% filter(appear.count==max(appear.count))

### Most distinct hits by use date descending order and calculate date with max usage by distinct usage

use_date<-as.data.frame(unique(my_data[,c(1,3)]) 
                        %>% select(Use_Date) 
                        %>% group_by(Use_Date) 
                        %>% summarise(appear.count=n())
                        %>% arrange(desc(appear.count)))

use_date %>% select(Use_Date,appear.count) %>% filter(appear.count==max(appear.count))



######################PLOTS########################333333


##Turninig on Graphic Device

pdf(file= "GraphsforR4.pdf")

###### Plot for shift of genre each week for every distinct user.


u_genre2<-as.data.frame(unique(my_data[,c(1,3,4)]) 
                        %>% select(Genre,Use_Date) 
                        %>% group_by(Use_Date,Genre) 
                        %>% summarise(appear.count=n()) 
                        %>% arrange((Use_Date))) 
plot(u_genre2$Use_Date,u_genre2$appear.count, pch = u_genre2$Genre, 
     main = " Graph for all distinct User's Shift")
ggplot(u_genre2, aes(x=Use_Date, y=appear.count, color=Genre, shape=Genre)) + 
  geom_line(size=1, alpha = .8) + ggtitle(" Graph for all distinct User's Shift")


###### Plot for Distinct user shift of genre each week 
#for all users for first week of signup.

u_genre3<-as.data.frame(unique(my_data) 
                        %>% select(Genre,Use_Date,Account_Active_Date) 
                        %>% group_by(Use_Date,Genre) 
                        %>% filter(Account_Active_Date< "2015-01-12")
                        %>% summarise(appear.count=n()) 
                        %>% arrange((Use_Date))) 

plot(u_genre3$Use_Date,u_genre3$appear.count, pch = u_genre3$Genre,
     main = " Graph for week one signed up distinct User's Shift ")

ggplot(u_genre3, aes(x=Use_Date, y=appear.count, color=Genre, shape=Genre)) + 
  geom_line(size=1, alpha = .8) + ggtitle(" Graph for week one signed up distinct User's Shift ")

###### Plot for Distinct user shift of genre each week 
#for all users for second week of signup.

u_genre4<-as.data.frame(unique(my_data) 
                        %>% select(Genre,Use_Date,Account_Active_Date) 
                        %>% group_by(Use_Date,Genre) 
                        %>% filter(Account_Active_Date> "2015-01-11")
                        %>% summarise(appear.count=n()) 
                        %>% arrange((Use_Date))) 

plot(u_genre4$Use_Date,u_genre4$appear.count, pch = u_genre4$Genre,
     main = " Graph for week two signed up distinct User's Shift ")

ggplot(u_genre4, aes(x=Use_Date, y=appear.count, col=Genre, shape=Genre)) + 
  geom_line(size=1, alpha = .8) + ggtitle(" Graph for week two signed up distinct User's Shift ")



#Plot of Genres vs all Views
ggplot(data = u_genre, aes(x=Genre, y=appear.count))+
  geom_bar(stat = "identity",fill = "lightblue") + ggtitle(" Plot of Genres vs all views")


#Plot of Genres vs distinct Views
ggplot(data = u_genre1, aes(x=Genre, y=appear.count))+
  geom_bar(stat = "identity",fill = "lightblue")+ ggtitle(" Plot of Genres vs distinct user's view")

#### Turning off Graphic device for later use
graphics.off()



